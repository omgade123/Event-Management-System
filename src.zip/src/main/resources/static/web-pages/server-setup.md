# Frontend Server Setup Instructions

This document provides instructions for setting up a local server to run the frontend.

## Using Node.js http-server (Recommended)

1. Install Node.js if you don't have it already from [https://nodejs.org/](https://nodejs.org/)

2. Install http-server globally:
   ```
   npm install -g http-server
   ```

3. Navigate to the frontend directory:
   ```
   cd frontend
   ```

4. Start the server:
   ```
   http-server -p 3000
   ```

5. Access the application at: `http://localhost:3000`

## Using Python Simple HTTP Server

If you have Python installed, you can use its built-in HTTP server:

### Python 3.x
```
cd frontend
python -m http.server 3000
```

### Python 2.x
```
cd frontend
python -m SimpleHTTPServer 3000
```

Access the application at: `http://localhost:3000`

## Using VS Code Live Server Extension

If you're using Visual Studio Code, you can use the Live Server extension:

1. Install the "Live Server" extension from the VS Code marketplace

2. Open the `index.html` file in VS Code

3. Click on "Go Live" in the bottom right corner of the VS Code window

The application will open in your default browser.
