/**
 * Authentication Service
 * Handles login, registration, and token management
 */
class AuthService {
    constructor() {
        this.token = localStorage.getItem(CONFIG.TOKEN_KEY);
        this.user = JSON.parse(localStorage.getItem(CONFIG.USER_KEY) || 'null');
    }

    /**
     * Check if user is authenticated
     * @returns {boolean} authentication status
     */
    isAuthenticated() {
        return !!this.token;
    }

    /**
     * Get the current JWT token
     * @returns {string|null} the JWT token
     */
    getToken() {
        return this.token;
    }

    /**
     * Get the current user
     * @returns {Object|null} the user object
     */
    getUser() {
        return this.user;
    }

    /**
     * Check if current user has a specific role
     * @param {string} role - The role to check (e.g., 'NORMAL', 'ORGANIZER')
     * @returns {boolean} true if user has the role
     */
    hasRole(role) {
        return this.user && this.user.type === role;
    }

    /**
     * Login a user
     * @param {Object} credentials - User credentials (email, password)
     * @returns {Promise} Promise with user data and token
     */
    async login(credentials) {
        try {
            const response = await fetch(`http://localhost:8080/auth/login`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(credentials)
            });

            if (!response.ok) {
                const errorData = await response.json();
                throw new Error(errorData.message || 'Login failed');
            }

            const data = await response.json();
            this.token = data.token;
            localStorage.setItem(CONFIG.TOKEN_KEY, this.token);

            // Fetch user details
            await this.fetchUserDetails();
            
            return this.user;
        } catch (error) {
            console.error('Login error:', error);
            throw error;
        }
    }

    /**
     * Register a new user
     * @param {Object} userData - User registration data
     * @returns {Promise} Promise with registered user data
     */
    async register(userData) {
        try {
            const response = await fetch(`http://localhost:8080/auth/register`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(userData)
            });

            if (!response.ok) {
                const errorData = await response.json();
                throw new Error(errorData.message || 'Registration failed');
            }

            return await response.json();
        } catch (error) {
            console.error('Registration error:', error);
            throw error;
        }
    }

    /**
     * Fetch current user details
     * @returns {Promise} Promise with user data
     */
    async fetchUserDetails() {
        try {
            const response = await fetch(`${CONFIG.API_URL}/users/me`, {
                headers: {
                    'Authorization': `Bearer ${this.token}`
                }
            });

            if (!response.ok) {
                throw new Error('Failed to fetch user details');
            }

            this.user = await response.json();
            localStorage.setItem(CONFIG.USER_KEY, JSON.stringify(this.user));
            return this.user;
        } catch (error) {
            console.error('Error fetching user details:', error);
            throw error;
        }
    }    /**
     * Logout the current user
     */
    logout() {
        this.token = null;
        this.user = null;
        localStorage.removeItem(CONFIG.TOKEN_KEY);
        localStorage.removeItem(CONFIG.USER_KEY);
        
        // Clear user name in the UI
        const userNameElement = document.getElementById('user-name');
        if (userNameElement) {
            userNameElement.textContent = '';
        }
        
        window.location.href = CONFIG.ROUTES.LOGIN;
    }
}

// Create a global instance of the auth service
const auth = new AuthService();
