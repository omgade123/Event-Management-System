(() => {
  const apiUrl = "http://localhost:8080/api";
  const generateRandomColor = () => {
    const letters = "0123456789ABCDEF";
    let color = "#";
    for (let i = 0; i < 6; i++) {
      color += letters[Math.floor(Math.random() * 16)];
    }
    return color;
  };
  const rainbowColors = [
    "#FF6384", // Red
    "#FF9F40", // Orange
    "#FFCD56", // Yellow
    "#4BC0C0", // Teal
    "#36A2EB", // Blue
    "#9966FF", // Purple
    "#C9CBCF", // Light Gray
    "#00FF00", // Lime
    "#FF69B4", // Pink
    "#8B4513", // Brown
  ];

  //  Fetch student, course, and instructor counts
  fetch(`${apiUrl}/admindashboard`, {
    method: "GET",
    headers: {
      "Content-Type": "application/json",
      Authorization: getAuthorization(),
    },
  })
    .then((res) => res.json())
    .then((data) => {
      const studentCount = data.studentCount;
      //console.log(`Total students: ${studentCount}`);

      document.getElementById("studentCount").textContent += studentCount;
      const courseCount = data.courseCount;
      document.getElementById("courseCount").textContent = courseCount;
      const instructorCount = data.instructorCount;
      document.getElementById("instructorCount").textContent = instructorCount;
    });

  // Fetch course distribution data
  fetch(`${apiUrl}/admindashboard/popularCourses`, {
    method: "GET",
    headers: {
      "Content-Type": "application/json",
      Authorization: getAuthorization(),
    },
  })
    .then((res) => res.json())
    .then((data) => {
      const courseCountMap = {};
      data.forEach((course) => {
        courseCountMap[course.title] = course.countOfEnrollments;
      });
      const chartData = Object.entries(courseCountMap).map(([title, count]) => {
        return {
          title: title,
          count: count,
        };
      });
      renderBarChart(chartData);
      // Sort courses by number of enrollments and take the top 4

      const popularCourses = data
        .sort((a, b) => b.countOfEnrollments - a.countOfEnrollments)
        .slice(0, 4);
      const listContainer = document.querySelector(".list-group");
      listContainer.innerHTML = "";

      popularCourses.forEach((course) => {
        const listItem = document.createElement("li");
        listItem.className =
          "list-group-item d-flex justify-content-between align-items-center";
        listItem.textContent = `${course.title} - ${course.countOfEnrollments} students`;
        listContainer.appendChild(listItem);
      });
    })
    .catch((err) => console.error("Error fetching popular courses:", err));

  // Function to render bar chart
  function renderBarChart(data) {
    const barColors = data.map(
      (_, i) => rainbowColors[i % rainbowColors.length]
    );
    const ctx = document.getElementById("popularCoursesChart").getContext("2d");
    new Chart(ctx, {
      type: "bar",
      data: {
        labels: data.map((item) => item.title),
        datasets: [
          {
            label: "Number of Enrollments",
            data: data.map((item) => item.count),
            backgroundColor: barColors,
            borderColor: barColors,
            borderWidth: 1,
          },
        ],
      },
      options: {
        responsive: true,
        scales: {
          y: {
            beginAtZero: true,
            title: { display: true, text: "Enrollments" },
          },
          x: {
            title: { display: true, text: "Courses", align: "center" },
          },
        },
      },
    });
  }

  fetch(`${apiUrl}/admindashboard/studentEnrolled`, {
    method: "GET",
    headers: {
      "Content-Type": "application/json",
      Authorization: getAuthorization(),
    },
  })
    .then((res) => res.json())
    .then((data) => {
      const labels = data.map((item) => item.instructorName);
      const counts = data.map((item) => item.studentEnrolled);
      
      const backgroundColors = labels.map(
        (_, i) => `hsl(${(i * 360) / labels.length}, 70%, 60%)`
      );

      new Chart(document.getElementById("studentDistributionChart"), {
        type: "pie",
        data: {
          labels: labels,
          datasets: [
            {
              data: counts,
              backgroundColor: backgroundColors,
            },
          ],
        },
        options: {
          plugins: {
            title: {
              display: true,
              text: "Enrollments per Instructor",
            },
            legend: {
              position: "bottom",
            },
          },
        },
      });
    });

  // Fetch recent enrollments
  fetch(`${apiUrl}/admindashboard/recentEnrollments`, {
    method: "GET",
    headers: {
      "Content-Type": "application/json",
      Authorization: getAuthorization(),
    },
  })
    .then((res) => res.json())
    .then((enrollments) => {
      const list = document.getElementById("recentEnrollment");
      list.innerHTML = "";
      // Sort enrollments by date descending and take the latest 4
      //console.log(enrollments);
      enrollments.forEach((enrollment) => {
        const li = document.createElement("li");
        li.className = "list-group-item";
        li.textContent = `${enrollment.userName} enrolled in ${enrollment.courseTitle}`;
        list.appendChild(li);
      });
    })
    .catch((err) => console.error("Error fetching enrollment data:", err));
})();
