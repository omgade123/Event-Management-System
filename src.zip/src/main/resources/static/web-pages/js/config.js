/**
 * Configuration settings for the application
 */
const CONFIG = {
    // API base URL
    API_URL: 'http://localhost:8080/api',
    
    // JWT Token storage key
    TOKEN_KEY: 'eventManagementToken',
    
    // User storage key
    USER_KEY: 'eventManagementUser',
    
    // Routes
    ROUTES: {
        HOME: '#/home',
        LOGIN: '#/login',
        REGISTER: '#/register',
        DASHBOARD: '#/dashboard',
        EVENTS: '#/events',
        EVENT_DETAILS: '#/events/',
        MY_EVENTS: '#/my-events',
        PROFILE: '#/profile',
        EVENT_FORM: '#/event-form',
        EDIT_EVENT: '#/editevent', // New route for editing events
        EVENT_MANAGEMENT: '#/event-management',
        REPORTS: '#/reports',
        CHARTS: '#/charts'
    },
    
    // Events per page for pagination
    EVENTS_PER_PAGE: 10,
    
    // Chart colors
    CHART_COLORS: [
        'rgba(52, 152, 219, 0.8)',
        'rgba(46, 204, 113, 0.8)',
        'rgba(155, 89, 182, 0.8)',
        'rgba(52, 73, 94, 0.8)',
        'rgba(243, 156, 18, 0.8)'
    ],
    
    // Date and time format
    DATE_FORMAT: { year: 'numeric', month: 'long', day: 'numeric' },
    TIME_FORMAT: { hour: '2-digit', minute: '2-digit' }
};
