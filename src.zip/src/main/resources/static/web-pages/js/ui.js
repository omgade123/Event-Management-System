/**
 * UI Utilities
 * Handles common UI operations
 */
class UIService {
    constructor() {
        this.mainContent = document.getElementById('main-content');
        this.sidebarMenu = document.getElementById('sidebar-menu');
        this.userName = document.getElementById('user-name');
        this.logoutBtn = document.getElementById('logout-btn');
        this.sidebarToggle = document.getElementById('sidebarCollapse');
        this.sidebar = document.getElementById('sidebar');
        this.content = document.getElementById('content');
        this.toast = new bootstrap.Toast(document.getElementById('toast-notification'));
        this.toastTitle = document.getElementById('toast-title');
        this.toastMessage = document.getElementById('toast-message');
        this.toastElement = document.getElementById('toast-notification');
        
        this.setupEventListeners();
    }
      /**
     * Initialize UI event listeners
     */
    setupEventListeners() {
        // Sidebar toggle
        this.sidebarToggle.addEventListener('click', () => {
            this.sidebar.classList.toggle('active');
            this.content.classList.toggle('active');
        });
        
        // Logout button
        this.logoutBtn.addEventListener('click', () => {
            auth.logout();
        });
        
        // Check current route on page load to hide/show UI elements appropriately
        this.checkRouteForUIElements();
        
        // Listen for hash changes to update UI elements
        window.addEventListener('hashchange', () => {
            this.checkRouteForUIElements();
        });
    }
    
    /**
     * Check current route and update UI elements accordingly
     */
    checkRouteForUIElements() {
        const currentRoute = window.location.hash || CONFIG.ROUTES.HOME;
        const isAuthPage = currentRoute === CONFIG.ROUTES.LOGIN || currentRoute === CONFIG.ROUTES.REGISTER;
        
        // Adjust UI elements based on current route
        this.logoutBtn.style.display = isAuthPage ? 'none' : 'block';
    }
    
    /**
     * Render sidebar menu based on user role
     */
    renderSidebar() {
        this.sidebarMenu.innerHTML = '';
        const menuItems = [];
        
        // Common menu items
        menuItems.push({
            id: 'home',
            label: 'Home',
            icon: 'fa-home',
            route: CONFIG.ROUTES.HOME
        });
        
        // User type specific menu items
        if (auth.hasRole('NORMAL')) {
            menuItems.push(
                {
                    id: 'upcoming-events',
                    label: 'Upcoming Events',
                    icon: 'fa-calendar',
                    route: CONFIG.ROUTES.EVENTS
                },
                {
                    id: 'my-registrations',
                    label: 'My Registrations',
                    icon: 'fa-list-check',
                    route: CONFIG.ROUTES.MY_EVENTS
                }
            );
        } else if (auth.hasRole('ORGANIZER')) {
            menuItems.push(
                {
                    id: 'dashboard',
                    label: 'Dashboard',
                    icon: 'fa-tachometer-alt',
                    route: CONFIG.ROUTES.DASHBOARD
                },
                {
                    id: 'event-form',
                    label: 'Create Event',
                    icon: 'fa-plus-circle',
                    route: CONFIG.ROUTES.EVENT_FORM
                },
                {
                    id: 'event-management',
                    label: 'Event Master',
                    icon: 'fa-tasks',
                    route: CONFIG.ROUTES.EVENT_MANAGEMENT
                },
                {
                    id: 'reports',
                    label: 'Reports',
                    icon: 'fa-file-alt',
                    route: CONFIG.ROUTES.REPORTS
                },
                {
                    id: 'charts',
                    label: 'Charts',
                    icon: 'fa-chart-bar',
                    route: CONFIG.ROUTES.CHARTS
                }
            );
        }
        
        // Common bottom menu items
        menuItems.push({
            id: 'profile',
            label: 'Profile',
            icon: 'fa-user',
            route: CONFIG.ROUTES.PROFILE
        });
        
        // Create menu HTML
        const ul = document.createElement('ul');
        ul.className = 'sidebar-menu';
        
        menuItems.forEach(item => {
            const li = document.createElement('li');
            const a = document.createElement('a');
            a.className = 'menu-item';
            a.href = item.route;
            a.dataset.route = item.id;
            a.innerHTML = `<i class="fas ${item.icon}"></i> ${item.label}`;
            li.appendChild(a);
            ul.appendChild(li);
        });
        
        this.sidebarMenu.appendChild(ul);
        this.setActiveMenuItem();
    }
    
    /**
     * Set active menu item based on current route
     */
    setActiveMenuItem() {
        const currentRoute = window.location.hash || CONFIG.ROUTES.HOME;
        const menuItems = document.querySelectorAll('.menu-item');
        
        menuItems.forEach(item => {
            if (item.href === currentRoute || currentRoute.startsWith(item.href)) {
                item.classList.add('active');
            } else {
                item.classList.remove('active');
            }
        });
    }
      /**
     * Update user info in header
     */
    updateUserInfo() {
        const user = auth.getUser();
        const currentRoute = window.location.hash || CONFIG.ROUTES.HOME;
        const isAuthPage = currentRoute === CONFIG.ROUTES.LOGIN || currentRoute === CONFIG.ROUTES.REGISTER;
        
        // Don't update user info on auth pages
        if (isAuthPage) {
            this.userName.textContent = '';
            return;
        }
        
        if (user) {
            this.userName.textContent = user.name;
        } else {
            this.userName.textContent = '';
        }
    }
    
    /**
     * Show loading spinner
     */
    showLoading() {
        let spinner = document.querySelector('.spinner-overlay');
        if (!spinner) {
            spinner = document.createElement('div');
            spinner.className = 'spinner-overlay';
            spinner.innerHTML = `
                <div class="spinner-border text-primary" role="status">
                    <span class="visually-hidden">Loading...</span>
                </div>
            `;
            document.body.appendChild(spinner);
        }
        spinner.style.display = 'flex';
    }
    
    /**
     * Hide loading spinner
     */
    hideLoading() {
        const spinner = document.querySelector('.spinner-overlay');
        if (spinner) {
            spinner.style.display = 'none';
        }
    }
    
    /**
     * Show notification toast
     * @param {string} message - Toast message
     * @param {string} title - Toast title
     * @param {string} type - Toast type (success, error, warning)
     */
    showToast(message, title = 'Notification', type = 'info') {
        this.toastElement.className = `toast ${type}`;
        this.toastTitle.textContent = title;
        this.toastMessage.textContent = message;
        this.toast.show();
    }
    
    /**
     * Render content in the main container
     * @param {string|HTMLElement} content - HTML content to render
     */
    renderContent(content) {
        if (typeof content === 'string') {
            this.mainContent.innerHTML = content;
        } else {
            this.mainContent.innerHTML = '';
            this.mainContent.appendChild(content);
        }
    }
    
    /**
     * Format date
     * @param {string} dateStr - Date string
     * @returns {string} Formatted date
     */
    formatDate(dateStr) {
        if (!dateStr) return '';
        const date = new Date(dateStr);
        return date.toLocaleDateString('en-US', CONFIG.DATE_FORMAT);
    }
    
    /**
     * Format time
     * @param {string} timeStr - Time string
     * @returns {string} Formatted time
     */
    formatTime(timeStr) {
        if (!timeStr) return '';
        // Parsing time in format HH:MM:SS
        const [hours, minutes] = timeStr.split(':');
        const date = new Date();
        date.setHours(hours);
        date.setMinutes(minutes);
        return date.toLocaleTimeString('en-US', CONFIG.TIME_FORMAT);
    }
    
    /**
     * Check if date is in the past
     * @param {string} dateStr - Date string
     * @returns {boolean} True if date is in the past
     */
    isPastEvent(dateStr, timeStr) {
        const now = new Date();
        const eventDate = new Date(dateStr);
        
        if (timeStr) {
            const [hours, minutes] = timeStr.split(':');
            eventDate.setHours(parseInt(hours));
            eventDate.setMinutes(parseInt(minutes));
        }
        
        return eventDate < now;
    }
}

// Create a global instance of the UI service
const ui = new UIService();
