/**
 * Router
 * Handles SPA routing
 */
class Router {
    constructor() {
        this.routes = {
            [CONFIG.ROUTES.LOGIN]: 'login.html',
            [CONFIG.ROUTES.REGISTER]: 'register.html',
            [CONFIG.ROUTES.HOME]: 'home.html',
            [CONFIG.ROUTES.DASHBOARD]: 'dashboard.html',
            [CONFIG.ROUTES.EVENTS]: 'events.html',
            [CONFIG.ROUTES.MY_EVENTS]: 'my-events.html',
            [CONFIG.ROUTES.PROFILE]: 'profile.html',
            [CONFIG.ROUTES.EVENT_FORM]: 'event-form.html',
            [CONFIG.ROUTES.EDIT_EVENT]: 'editevent.html',
            [CONFIG.ROUTES.EVENT_MANAGEMENT]: 'event-management.html',
            [CONFIG.ROUTES.REPORTS]: 'reports.html',
            [CONFIG.ROUTES.CHARTS]: 'charts.html'
        };
        
        this.init();
    }
    
    /**
     * Initialize router
     */
    init() {
        window.addEventListener('hashchange', this.handleRouteChange.bind(this));
        window.addEventListener('load', this.handleRouteChange.bind(this));
    }
    
    /**
     * Navigate to a specific route
     * @param {string} route - Route to navigate to
     */
    navigateTo(route) {
        window.location.hash = route;
    }
    
    /**
     * Handle route change
     */
    async handleRouteChange() {
        // Check authentication
        const isAuthenticated = auth.isAuthenticated();
        const currentRoute = window.location.hash || CONFIG.ROUTES.HOME;
        
        // Toggle sidebar visibility based on route
        const isAuthPage = currentRoute === CONFIG.ROUTES.LOGIN || currentRoute === CONFIG.ROUTES.REGISTER;
        document.getElementById('sidebar').style.display = isAuthPage ? 'none' : 'block';
        document.querySelector('.user-info').style.display = isAuthPage ? 'none' : 'flex';
        document.getElementById('sidebarCollapse').style.display = isAuthPage ? 'none' : 'block';
        document.getElementById('logout-btn').style.display = isAuthPage ? 'none' : 'block';
        
        // Set content to full width on auth pages
        document.getElementById('content').style.marginLeft = isAuthPage ? '0' : '';
        
        // Center logo on auth pages
        document.querySelector('.navbar-brand').className = isAuthPage ? 'navbar-brand mx-auto' : 'navbar-brand';
        
        // Clear user name when on auth pages
        if (isAuthPage) {
            document.getElementById('user-name').textContent = '';
        }
        
        // Authentication redirect checks
        if (!isAuthenticated && !isAuthPage) {
            this.navigateTo(CONFIG.ROUTES.LOGIN);
            return;
        }
        
        if (isAuthenticated && isAuthPage) {
            this.navigateTo(CONFIG.ROUTES.HOME);
            return;
        }
        
        // Update UI for authenticated users
        if (isAuthenticated) {
            ui.updateUserInfo();
            ui.renderSidebar();
        }
        
        // Load the appropriate page template
        try {
            ui.showLoading();
            const templateFile = this.getTemplateFile(currentRoute);
            await this.loadPage(templateFile);
            
            // Initialize page-specific functionality
            this.initPageFunctionality(currentRoute);
        } catch (error) {
            console.error('Error loading page:', error);
            ui.showToast(error.message || 'An error occurred loading the page', 'Error', 'error');
        } finally {
            ui.hideLoading();
        }
    }
    
    /**
     * Get page template name based on route
     * @param {string} route - The route
     * @returns {string} Template file name
     */
    getTemplateFile(route) {
        // Check for exact match
        if (this.routes[route]) {
            return this.routes[route];
        }
        
        // Check for dynamic routes
        if (route.startsWith(CONFIG.ROUTES.EVENT_FORM + '/')) {
            return 'event-form.html';
        } else if (route.startsWith(CONFIG.ROUTES.EVENT_DETAILS + '/')) {
            return 'event-details.html';
        } else if (route.startsWith(CONFIG.ROUTES.EDIT_EVENT + '/')) {
            return 'editevent.html';
        }
        
        // Default to 404 page
        return '404.html';
    }
    
    /**
     * Load a page template into the main content area
     * @param {string} templateFile - Template file name
     * @returns {Promise} Promise resolved when page is loaded
     */
    async loadPage(templateFile) {
        try {
            const response = await fetch(`pages/${templateFile}`);
            if (!response.ok) {
                throw new Error(`Failed to load page template: ${templateFile}`);
            }
            
            const html = await response.text();
            ui.renderContent(html);
            return html;
        } catch (error) {
            console.error('Error loading page template:', error);
            throw error;
        }
    }
    
    /**
     * Initialize page-specific functionality
     * @param {string} route - Current route
     */
    initPageFunctionality(route) {
        // Handle page-specific initialization based on route
        switch (route) {
            case CONFIG.ROUTES.LOGIN:
                this.initLoginPage();
                break;
            case CONFIG.ROUTES.REGISTER:
                this.initRegisterPage();
                break;
            case CONFIG.ROUTES.HOME:
                this.initHomePage();
                break;
            case CONFIG.ROUTES.PROFILE:
                this.initProfilePage();
                break;
            case CONFIG.ROUTES.EVENTS:
                this.initEventsPage();
                break;
            case CONFIG.ROUTES.MY_EVENTS:
                this.initMyEventsPage();
                break;
            case CONFIG.ROUTES.DASHBOARD:
                this.initDashboardPage();
                break;
            case CONFIG.ROUTES.EVENT_FORM:
                this.initEventFormPage();
                break;
            case CONFIG.ROUTES.EVENT_MANAGEMENT:
                this.initEventManagementPage();
                break;
            case CONFIG.ROUTES.REPORTS:
                this.initReportsPage();
                break;
            case CONFIG.ROUTES.CHARTS:
                this.initChartsPage();
                break;
            default:
                // Handle dynamic routes
                if (route.startsWith(CONFIG.ROUTES.EVENT_FORM + '/')) {
                    const eventId = route.split('/')[2];
                    this.initEventFormPage(eventId);
                } else if (route.startsWith(CONFIG.ROUTES.EDIT_EVENT + '/')) {
                    const eventId = route.split('/')[2];
                    this.initEditEventPage(eventId);
                }
        }
    }
    
    /**
     * Initialize login page functionality
     */
    initLoginPage() {
        document.getElementById('login-form').addEventListener('submit', async (e) => {
            e.preventDefault();
            e.stopPropagation();
            
            const form = e.target;
            form.classList.add('was-validated');
            
            if (!form.checkValidity()) {
                return;
            }
            
            const credentials = {
                email: document.getElementById('email').value,
                password: document.getElementById('password').value
            };
            
            try {
                ui.showLoading();
                await auth.login(credentials);
                this.navigateTo(CONFIG.ROUTES.HOME);
                ui.showToast('Login successful', 'Welcome', 'success');
            } catch (error) {
                ui.showToast(error.message || 'Login failed', 'Error', 'error');
            } finally {
                ui.hideLoading();
            }
        });
    }
    
    /**
     * Initialize register page functionality
     */
    initRegisterPage() {
        document.getElementById('register-form').addEventListener('submit', async (e) => {
            e.preventDefault();
            e.stopPropagation();
            
            const form = e.target;
            form.classList.add('was-validated');
            
            if (!form.checkValidity()) {
                return;
            }
            
            const userData = {
                name: document.getElementById('name').value,
                email: document.getElementById('email').value,
                password: document.getElementById('password').value,
                phone: document.getElementById('phone').value,
                type: document.querySelector('input[name="userType"]:checked').value
            };
            
            try {
                ui.showLoading();
                await auth.register(userData);
                ui.showToast('Registration successful. Please login.', 'Success', 'success');
                this.navigateTo(CONFIG.ROUTES.LOGIN);
            } catch (error) {
                ui.showToast(error.message || 'Registration failed', 'Error', 'error');
            } finally {
                ui.hideLoading();
            }
        });
    }
    
    /**
     * Initialize home page functionality
     */
    initHomePage() {
        const user = auth.getUser();
        if (user) {
            document.getElementById('welcome-user-name').textContent = user.name;
            
            if (user.type === 'ORGANIZER') {
                document.getElementById('user-role-message').textContent = 'This is your event management dashboard.';
                document.getElementById('role-description').textContent = 'As an organizer, you can create and manage events, view reports and analytics.';
                document.getElementById('main-action-btn').textContent = 'Go to Dashboard';
                document.getElementById('main-action-btn').href = CONFIG.ROUTES.DASHBOARD;
            } else {
                document.getElementById('user-role-message').textContent = 'This is your event registration dashboard.';
                document.getElementById('role-description').textContent = 'Browse upcoming events and manage your event registrations.';
                document.getElementById('main-action-btn').textContent = 'Browse Events';
                document.getElementById('main-action-btn').href = CONFIG.ROUTES.EVENTS;
            }
        }
    }
    
    /**
     * Initialize profile page functionality
     */
    async initProfilePage() {
        try {
            const user = await api.getUserProfile();
            
            // Populate form with user data
            document.getElementById('profile-name').value = user.name;
            document.getElementById('profile-email').value = user.email;
            document.getElementById('profile-phone').value = user.phone;
            document.getElementById('profile-type').value = user.type;
            
            // Add form submission handler
            document.getElementById('profile-form').addEventListener('submit', async (e) => {
                e.preventDefault();
                e.stopPropagation();
                
                const form = e.target;
                form.classList.add('was-validated');
                
                if (!form.checkValidity()) {
                    return;
                }
                
                const userData = {
                    name: document.getElementById('profile-name').value,
                    phone: document.getElementById('profile-phone').value
                };
                
                try {
                    ui.showLoading();
                    // TODO: Implement profile update functionality when backend supports it
                    // await api.updateUserProfile(userData);
                    ui.showToast('Profile update functionality not implemented yet', 'Info', 'info');
                } catch (error) {
                    ui.showToast(error.message || 'Failed to update profile', 'Error', 'error');
                } finally {
                    ui.hideLoading();
                }
            });
        } catch (error) {
            ui.showToast(error.message || 'Failed to load profile', 'Error', 'error');
        }
    }
    
    /**
     * Initialize events page functionality (for normal users)
     */
    async initEventsPage() {
        try {
            // Fetch both upcoming events and registrations to check registration status
            const eventsResponse = await api.getUpcomingEvents();
            const registrationsResponse = await api.getRegisteredEvents();
            
            const events = eventsResponse.data;
            const registeredEvents = registrationsResponse.data.map(event => event.id);
            
            const container = document.getElementById('events-container');
            
            if (events.length === 0) {
                container.innerHTML = `
                    <div class="col-12">
                        <div class="alert alert-info">
                            No upcoming events found.
                        </div>
                    </div>
                `;
                return;
            }
            
            // Clear container
            container.innerHTML = '';
            
            // Add events
            events.forEach(event => {
                const col = document.createElement('div');
                col.className = 'col-md-4 mb-4';
                
                const isPast = ui.isPastEvent(event.date, event.time);
                const isRegistered = registeredEvents.includes(event.id);
                
                col.innerHTML = `
                    <div class="card event-card" data-event-id="${event.id}">
                        <div class="card-header d-flex justify-content-between align-items-center">
                            <h5 class="card-title mb-0">${event.title}</h5>
                            <span class="badge ${isPast ? 'bg-secondary' : 'bg-success'}">
                                ${isPast ? 'Past Event' : 'Upcoming'}
                            </span>
                        </div>
                        <div class="card-body">
                            <div class="row mb-3">
                                <div class="col-md-6">
                                    <p><i class="fas fa-calendar-day me-2"></i> ${ui.formatDate(event.date)}</p>
                                    <p><i class="fas fa-clock me-2"></i> ${ui.formatTime(event.time)}</p>
                                </div>
                                <div class="col-md-6">
                                    <p><i class="fas fa-map-marker-alt me-2"></i> ${event.location}</p>
                                    <p><i class="fas fa-tag me-2"></i> ${event.type}</p>
                                </div>
                            </div>                            <div class="d-flex justify-content-end">
                                ${!isPast ? 
                                    isRegistered ?
                                    `<button class="btn btn-success registered-btn" disabled data-event-id="${event.id}">
                                        <i class="fas fa-check"></i> Registered
                                     </button>` :
                                    `<button class="btn btn-primary register-btn" data-event-id="${event.id}">
                                        Register
                                     </button>`
                                : ''}
                            </div>
                        </div>
                    </div>
                `;
                
                container.appendChild(col);
                
                // Add event listener for register button
                if (!isPast && !isRegistered) {
                    const registerBtn = col.querySelector('.register-btn');
                    registerBtn.addEventListener('click', async () => {
                        try {
                            ui.showLoading();
                            await api.registerForEvent(event.id);
                              // Update button to show registered status
                            registerBtn.innerHTML = '<i class="fas fa-check"></i> Registered';
                            registerBtn.classList.remove('btn-primary', 'register-btn');
                            registerBtn.classList.add('btn-success', 'registered-btn');
                            registerBtn.disabled = true;
                            
                            ui.showToast('Successfully registered for event', 'Success', 'success');
                        } catch (error) {
                            ui.showToast(error.message || 'Failed to register for event', 'Error', 'error');
                        } finally {
                            ui.hideLoading();
                        }
                    });
                }
            });
        } catch (error) {
            ui.showToast(error.message || 'Failed to load events', 'Error', 'error');
        }
    }
    
    /**
     * Initialize my events page functionality
     */
    async initMyEventsPage() {
        try {
            const response = await api.getRegisteredEvents();
            const events = response.data;
            const container = document.getElementById('my-events-container');
            
            if (events.length === 0) {
                container.innerHTML = `
                    <div class="col-12">
                        <div class="alert alert-info">
                            You haven't registered for any events yet.
                        </div>
                    </div>
                `;
                return;
            }
            
            // Clear container
            container.innerHTML = '';
            
            // Add events
            events.forEach(event => {
                const col = document.createElement('div');
                col.className = 'col-md-4 mb-4';
                
                const isPast = ui.isPastEvent(event.date, event.time);
                
                col.innerHTML = `
                    <div class="card event-card">
                        <div class="card-header d-flex justify-content-between align-items-center">
                            <h5 class="card-title mb-0">${event.title}</h5>
                            <span class="badge ${isPast ? 'bg-secondary' : 'bg-success'}">
                                ${isPast ? 'Past Event' : 'Upcoming'}
                            </span>
                        </div>
                        <div class="card-body">
                            <p><i class="fas fa-calendar me-2"></i> ${ui.formatDate(event.date)}</p>
                            <p><i class="fas fa-clock me-2"></i> ${ui.formatTime(event.time)}</p>
                            <p><i class="fas fa-map-marker-alt me-2"></i> ${event.location}</p>
                            <p><i class="fas fa-tag me-2"></i> ${event.type}</p>
                            ${!isPast ? `
                                <div class="d-grid">
                                    <button class="btn btn-outline-danger cancel-registration-btn" data-event-id="${event.id}">
                                        Cancel Registration
                                    </button>
                                </div>
                            ` : ''}
                        </div>
                    </div>
                `;
                
                container.appendChild(col);
                
                // Add event listener for cancel button
                if (!isPast) {
                    const cancelBtn = col.querySelector('.cancel-registration-btn');
                    cancelBtn.addEventListener('click', async () => {
                        if (confirm('Are you sure you want to cancel your registration?')) {
                            try {
                                ui.showLoading();
                                await api.cancelRegistration(event.id);
                                ui.showToast('Registration canceled successfully', 'Success', 'success');
                                // Refresh the page
                                this.navigateTo(CONFIG.ROUTES.MY_EVENTS);
                            } catch (error) {
                                ui.showToast(error.message || 'Failed to cancel registration', 'Error', 'error');
                            } finally {
                                ui.hideLoading();
                            }
                        }
                    });
                }
            });
        } catch (error) {
            ui.showToast(error.message || 'Failed to load your events', 'Error', 'error');
        }
    }
    
    /**
     * Initialize dashboard page functionality
     */
    async initDashboardPage() {
        try {
            if (!auth.hasRole('ORGANIZER')) {
                this.navigateTo(CONFIG.ROUTES.HOME);
                return;
            }

            // Fetch dashboard data
            const reportPromise = api.getEventsReport();
            const eventsPromise = api.getEvents(); // Fetch all events for the organizer

            const [reportsResponse, eventsResponse] = await Promise.all([reportPromise, eventsPromise]);
            
            const report = reportsResponse.data || {};
            const allOrganizerEvents = eventsResponse.data || [];

            // Set defaults for missing values
            const reportData = {
                totalEvents: report.totalEvents || 0,
                upcomingEvents: report.upcomingEvents || 0,
                pastEvents: report.pastEvents || 0,
                totalRegistrations: report.totalParticipants || 0, // Use totalParticipants from the backend report
            };

            // Populate stats
            const statsContainer = document.getElementById('stats-container');
            statsContainer.innerHTML = `
                <div class="col-md-3 mb-4">
                    <div class="stats-card">
                        <div class="d-flex align-items-center">
                            <div class="stats-card-icon">
                                <i class="fas fa-calendar-alt"></i>
                            </div>
                            <div>
                                <div class="stats-card-value">${reportData.totalEvents}</div>
                                <div class="stats-card-label">Total Events</div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 mb-4">
                    <div class="stats-card">
                        <div class="d-flex align-items-center">
                            <div class="stats-card-icon">
                                <i class="fas fa-calendar-check"></i>
                            </div>
                            <div>
                                <div class="stats-card-value">${reportData.upcomingEvents}</div>
                                <div class="stats-card-label">Upcoming Events</div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 mb-4">
                    <div class="stats-card">
                        <div class="d-flex align-items-center">
                            <div class="stats-card-icon">
                                <i class="fas fa-calendar-times"></i>
                            </div>
                            <div>
                                <div class="stats-card-value">${reportData.pastEvents}</div>
                                <div class="stats-card-label">Past Events</div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 mb-4">
                    <div class="stats-card">
                        <div class="d-flex align-items-center">
                            <div class="stats-card-icon">
                                <i class="fas fa-users"></i>
                            </div>
                            <div>
                                <div class="stats-card-value">${reportData.totalRegistrations}</div>
                                <div class="stats-card-label">Registrations</div>
                            </div>
                        </div>
                    </div>
                </div>
            `;            const recentEventsContainer = document.getElementById('recent-events');
            
            // Filter to only include upcoming events from the organizer's events
            const upcomingEvents = allOrganizerEvents.filter(event => {
                if (!event) return false;
                return !ui.isPastEvent(event.date, event.time);
            }).sort((a, b) => new Date(a.date) - new Date(b.date)); // Sort by date

            if (upcomingEvents.length > 0) {
                recentEventsContainer.innerHTML = ''; // Clear existing
                upcomingEvents.slice(0, 5).forEach(event => { // Show top 5 upcoming
                    // Calculate if the event is today
                    const eventDate = new Date(event.date);
                    const today = new Date();
                    const isToday = eventDate.getDate() === today.getDate() && 
                                   eventDate.getMonth() === today.getMonth() && 
                                   eventDate.getFullYear() === today.getFullYear();
                    
                    // Calculate days until event
                    const timeDiff = eventDate.getTime() - today.getTime();
                    const daysUntil = Math.ceil(timeDiff / (1000 * 3600 * 24));
                    
                    const listItem = document.createElement('a');
                    listItem.className = 'list-group-item list-group-item-action';
                    listItem.href = `${CONFIG.ROUTES.EVENT_FORM}/${event.id}`;
                    
                    listItem.innerHTML = `
                        <div class="d-flex w-100 justify-content-between">
                            <h6 class="mb-1">${event.title || 'Untitled Event'}</h6>
                            <span class="badge ${isToday ? 'bg-warning' : 'bg-success'}">
                                ${isToday ? 'Today' : 'Upcoming'}
                            </span>
                        </div>
                        <p class="mb-1">
                            <small>
                                <i class="fas fa-calendar me-1"></i> ${ui.formatDate(event.date || new Date())}
                                ${event.time ? `<i class="fas fa-clock ms-2 me-1"></i> ${ui.formatTime(event.time)}` : ''}
                                ${!isToday ? `<span class="ms-2 event-countdown"><i class="fas fa-hourglass-half me-1"></i>In ${daysUntil} day${daysUntil !== 1 ? 's' : ''}</span>` : ''}
                            </small>
                        </p>
                    `;
                    
                    recentEventsContainer.appendChild(listItem);
                });
            } else {
                recentEventsContainer.innerHTML = `<div class="list-group-item">No upcoming events found</div>`;
            }
            
            // Populate popular events
            // Use the 'events' array from the 'report' object (from api.getEventsReport()), which contains EventDtos with participant counts.
            if (Array.isArray(report?.events) && report.events.length > 0) {
                const detailedEvents = [...report.events]; 

                // Sort events by participant count (registrations) in descending order
                detailedEvents.sort((a, b) => (b.participants || 0) - (a.participants || 0));

                const popularEvents = detailedEvents.slice(0, 5); // Get top 5

                const popularEventsContainer = document.getElementById('popular-events');
                popularEventsContainer.innerHTML = ''; // Clear existing content

                if (popularEvents.length > 0) {
                    popularEvents.forEach(event => {
                        const listItem = document.createElement('div');
                        listItem.className = 'list-group-item popular-event-item'; 

                        listItem.innerHTML = `
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <h6 class="mb-1">${event.title}</h6>
                                    <small class="text-muted">
                                        <span class="registration-count">${event.participants || 0}</span> registrations
                                    </small>
                                </div>
                            </div>
                        `;
                        popularEventsContainer.appendChild(listItem);
                    });
                } else {
                    popularEventsContainer.innerHTML = '<div class="list-group-item">No popular events found.</div>';
                }
            } else {
                const popularEventsContainer = document.getElementById('popular-events');
                popularEventsContainer.innerHTML = '<div class="list-group-item">No popular events to display or data is unavailable.</div>';
                console.error('Failed to populate popular events: report.events is not an array or is empty. Report data:', report);
            }

            // Set up refresh button
            document.getElementById('refresh-dashboard-btn').addEventListener('click', async () => {
                ui.showToast('Refreshing dashboard data...', 'Info', 'info');
                await this.initDashboardPage();
                ui.showToast('Dashboard refreshed', 'Success', 'success');
            });
            
        } catch (error) {
            ui.showToast(error.message || 'Failed to load dashboard', 'Error', 'error');
        }
    }
    
    /**
     * Initialize event form page functionality
     * @param {string} eventId - Event ID for editing (optional)
     */
    async initEventFormPage(eventId = null) {
        try {
            if (!auth.hasRole('ORGANIZER')) {
                this.navigateTo(CONFIG.ROUTES.HOME);
                return;
            }
            
            const formTitle = document.getElementById('form-title');
            const saveBtn = document.getElementById('save-event-btn');
            const eventIdField = document.getElementById('event-id');
            
            if (eventId) {
                // Edit mode
                formTitle.textContent = 'Edit Event';
                saveBtn.textContent = 'Update Event';
                eventIdField.value = eventId;
                
                // Fetch event data for editing
                const response = await api.request(`/events/${eventId}`);
                const eventData = response.data;
                
                // Populate form fields
                document.getElementById('event-title').value = eventData.title;
                document.getElementById('event-date').value = eventData.date;
                document.getElementById('event-time').value = eventData.time ? eventData.time.substring(0, 5) : '';
                document.getElementById('event-type').value = eventData.type;
                document.getElementById('event-location').value = eventData.location;
            } else {
                // Create mode
                formTitle.textContent = 'Create Event';
                saveBtn.textContent = 'Create Event';
                eventIdField.value = '';
                
                // Clear form fields
                document.getElementById('event-form').reset();
            }
            
            // Add form submission handler
            document.getElementById('event-form').addEventListener('submit', async (e) => {
                e.preventDefault();
                e.stopPropagation();
                
                const form = e.target;
                form.classList.add('was-validated');
                
                if (!form.checkValidity()) {
                    return;
                }
                
                const eventData = {
                    title: document.getElementById('event-title').value,
                    date: document.getElementById('event-date').value,
                    time: document.getElementById('event-time').value,
                    type: document.getElementById('event-type').value,
                    location: document.getElementById('event-location').value
                };
                
                try {
                    ui.showLoading();
                    
                    if (eventId) {
                        await api.updateEvent(eventId, eventData);
                        ui.showToast('Event updated successfully', 'Success', 'success');
                    } else {
                        await api.createEvent(eventData);
                        ui.showToast('Event created successfully', 'Success', 'success');
                    }
                    
                    this.navigateTo(CONFIG.ROUTES.EVENT_MANAGEMENT);
                } catch (error) {
                    ui.showToast(error.message || 'Failed to save event', 'Error', 'error');
                } finally {
                    ui.hideLoading();
                }
            });
            
            // Add cancel button handler
            document.getElementById('cancel-btn').addEventListener('click', () => {
                this.navigateTo(CONFIG.ROUTES.EVENT_MANAGEMENT);
            });
        } catch (error) {
            ui.showToast(error.message || 'Failed to load event form', 'Error', 'error');
        }
    }
    
    /**
     * Initialize event management page functionality
     */
    async initEventManagementPage() {
        try {
            if (!auth.hasRole('ORGANIZER')) {
                this.navigateTo(CONFIG.ROUTES.HOME);
                return;
            }
            
            const response = await api.getEvents();
            const events = response.data;
            
            const upcomingContainer = document.getElementById('upcoming-events-container');
            const pastContainer = document.getElementById('past-events-container');
            
            upcomingContainer.innerHTML = '';
            pastContainer.innerHTML = '';
            
            let upcomingEvents = 0;
            let pastEvents = 0;
            
            if (events.length === 0) {
                upcomingContainer.innerHTML = `
                    <div class="col-12">
                        <div class="alert alert-info">No events found</div>
                    </div>
                `;
                pastContainer.innerHTML = `
                    <div class="col-12">
                        <div class="alert alert-info">No events found</div>
                    </div>
                `;
                return;
            }
            
            events.forEach(event => {
                const isPast = ui.isPastEvent(event.date, event.time);
                const col = document.createElement('div');
                col.className = 'col-md-4 mb-4';
                
                col.innerHTML = `
                    <div class="card event-card" data-event-id="${event.id}">
                        <div class="card-header d-flex justify-content-between align-items-center">
                            <h5 class="card-title mb-0">${event.title}</h5>
                            <span class="badge ${isPast ? 'bg-secondary' : 'bg-success'}">
                                ${isPast ? 'Past Event' : 'Upcoming'}
                            </span>
                        </div>
                        <div class="card-body">
                            <div class="row mb-3">
                                <div class="col-md-6">
                                    <p><i class="fas fa-calendar-day me-2"></i> ${ui.formatDate(event.date)}</p>
                                    <p><i class="fas fa-clock me-2"></i> ${ui.formatTime(event.time)}</p>
                                </div>
                                <div class="col-md-6">
                                    <p><i class="fas fa-map-marker-alt me-2"></i> ${event.location}</p>
                                    <p><i class="fas fa-tag me-2"></i> ${event.type}</p>
                                </div>
                            </div>
                            <div class="d-flex justify-content-end">
                                <button class="btn btn-sm btn-outline-primary edit-event-btn me-2" data-event-id="${event.id}">
                                    <i class="fas fa-edit"></i> Edit
                                </button>
                                <button class="btn btn-sm btn-outline-danger delete-event-btn" data-event-id="${event.id}">
                                    <i class="fas fa-trash"></i> Delete
                                </button>
                            </div>
                        </div>
                    </div>
                `;
                
                // Add event listeners
                col.querySelector('.edit-event-btn').addEventListener('click', () => {
                    this.navigateTo(`${CONFIG.ROUTES.EDIT_EVENT}/${event.id}`);
                });
                
                col.querySelector('.delete-event-btn').addEventListener('click', async () => {
                    if (confirm(`Are you sure you want to delete "${event.title}"?`)) {
                        try {
                            ui.showLoading();
                            await api.deleteEvent(event.id);
                            ui.showToast('Event deleted successfully', 'Success', 'success');
                            // Refresh the page
                            this.navigateTo(CONFIG.ROUTES.EVENT_MANAGEMENT);
                        } catch (error) {
                            ui.showToast(error.message || 'Failed to delete event', 'Error', 'error');
                        } finally {
                            ui.hideLoading();
                        }
                    }
                });
                
                if (isPast) {
                    pastContainer.appendChild(col);
                    pastEvents++;
                } else {
                    upcomingContainer.appendChild(col);
                    upcomingEvents++;
                }
            });
            
            if (upcomingEvents === 0) {
                upcomingContainer.innerHTML = `
                    <div class="col-12">
                        <div class="alert alert-info">No upcoming events found</div>
                    </div>
                `;
            }
            
            if (pastEvents === 0) {
                pastContainer.innerHTML = `
                    <div class="col-12">
                        <div class="alert alert-info">No past events found</div>
                    </div>
                `;
            }
        } catch (error) {
            ui.showToast(error.message || 'Failed to load events', 'Error', 'error');
        }
    }

    /**
     * Initialize Edit Event page functionality
     * @param {string} eventId - Event ID for editing
     */
    async initEditEventPage(eventId) {
        try {
            if (!auth.hasRole('ORGANIZER')) {
                this.navigateTo(CONFIG.ROUTES.HOME);
                return;
            }
            if (!eventId) {
                ui.showToast('Event ID is missing. Cannot edit event.', 'Error', 'error');
                this.navigateTo(CONFIG.ROUTES.EVENT_MANAGEMENT);
                return;
            }

            // Fetch event data
            const response = await api.request(`/events/${eventId}`);
            if (!response || !response.data) {
                ui.showToast('Failed to load event data.', 'Error', 'error');
                this.navigateTo(CONFIG.ROUTES.EVENT_MANAGEMENT);
                return;
            }
            const eventData = response.data;

            // Populate form fields
            document.getElementById('event-id').value = eventData.id;
            document.getElementById('event-title').value = eventData.title;
            document.getElementById('event-date').value = eventData.date;
            document.getElementById('event-time').value = eventData.time ? eventData.time.substring(0, 5) : '';
            document.getElementById('event-type').value = eventData.type;
            document.getElementById('event-location').value = eventData.location;
            
            // Add form submission handler for update
            const form = document.getElementById('edit-event-form');
            form.addEventListener('submit', async (e) => {
                e.preventDefault();
                e.stopPropagation();
                form.classList.add('was-validated');
                if (!form.checkValidity()) {
                    return;
                }

                const updatedEventData = {
                    title: document.getElementById('event-title').value,
                    date: document.getElementById('event-date').value,
                    time: document.getElementById('event-time').value,
                    type: document.getElementById('event-type').value,
                    location: document.getElementById('event-location').value
                };

                try {
                    ui.showLoading();
                    await api.updateEvent(eventId, updatedEventData);
                    ui.showToast('Event updated successfully', 'Success', 'success');
                    this.navigateTo(CONFIG.ROUTES.EVENT_MANAGEMENT);
                } catch (error) {
                    ui.showToast(error.message || 'Failed to update event', 'Error', 'error');
                } finally {
                    ui.hideLoading();
                }
            });

            // Add cancel button handler
            document.getElementById('cancel-edit-btn').addEventListener('click', () => {
                this.navigateTo(CONFIG.ROUTES.EVENT_MANAGEMENT);
            });

        } catch (error) {
            ui.showToast(error.message || 'Failed to load edit event page', 'Error', 'error');
            console.error("Error in initEditEventPage:", error);
            this.navigateTo(CONFIG.ROUTES.EVENT_MANAGEMENT);
        }
    }
}
    
// Create a global instance of the router
const router = new Router();
