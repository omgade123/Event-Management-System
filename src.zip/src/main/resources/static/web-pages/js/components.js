/**
 * UI Components
 * Reusable UI components for the application
 */
class Components {
    /**
     * Create an event card
     * @param {Object} event - Event data
     * @param {boolean} showRegisterButton - Whether to show register button
     * @param {boolean} showManageButtons - Whether to show manage buttons
     * @returns {HTMLElement} Event card element
     */
    createEventCard(event, showRegisterButton = true, showManageButtons = false) {
        const isPast = ui.isPastEvent(event.date, event.time);
        const card = document.createElement('div');
        card.className = 'card event-card mb-3';
        card.dataset.eventId = event.id;
        
        const statusBadge = isPast 
            ? '<span class="badge bg-secondary">Past Event</span>' 
            : '<span class="badge bg-success">Upcoming</span>';
        
        let buttons = '';
        
        if (showRegisterButton && !isPast) {
            buttons = `
                <button class="btn btn-primary register-btn" data-event-id="${event.id}">
                    Register
                </button>
            `;
        }
        
        if (showManageButtons) {
            buttons = `
                <button class="btn btn-sm btn-outline-primary edit-event-btn me-2" data-event-id="${event.id}">
                    <i class="fas fa-edit"></i> Edit
                </button>
                <button class="btn btn-sm btn-outline-danger delete-event-btn" data-event-id="${event.id}">
                    <i class="fas fa-trash"></i> Delete
                </button>
            `;
        }
        
        card.innerHTML = `
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="card-title mb-0">${event.title}</h5>
                ${statusBadge}
            </div>
            <div class="card-body">
                <div class="row mb-3">
                    <div class="col-md-6">
                        <p><i class="fas fa-calendar-day me-2"></i> ${ui.formatDate(event.date)}</p>
                        <p><i class="fas fa-clock me-2"></i> ${ui.formatTime(event.time)}</p>
                    </div>
                    <div class="col-md-6">
                        <p><i class="fas fa-map-marker-alt me-2"></i> ${event.location}</p>
                        <p><i class="fas fa-tag me-2"></i> ${event.type}</p>
                    </div>
                </div>
                <div class="d-flex justify-content-end">
                    ${buttons}
                </div>
            </div>
        `;
        
        // Add event listeners
        if (showRegisterButton && !isPast) {
            const registerBtn = card.querySelector('.register-btn');
            registerBtn.addEventListener('click', async (e) => {
                e.preventDefault();
                try {
                    ui.showLoading();
                    await api.registerForEvent(event.id);
                    ui.showToast('Successfully registered for event', 'Success', 'success');
                    // Refresh events
                    router.navigateTo(CONFIG.ROUTES.EVENTS);
                } catch (error) {
                    ui.showToast(error.message || 'Failed to register for event', 'Error', 'error');
                } finally {
                    ui.hideLoading();
                }
            });
        }
        
        if (showManageButtons) {
            const editBtn = card.querySelector('.edit-event-btn');
            const deleteBtn = card.querySelector('.delete-event-btn');
            
            editBtn.addEventListener('click', (e) => {
                e.preventDefault();
                router.navigateTo(`${CONFIG.ROUTES.EVENT_FORM}/${event.id}`);
            });
            
            deleteBtn.addEventListener('click', async (e) => {
                e.preventDefault();
                if (confirm(`Are you sure you want to delete "${event.title}"?`)) {
                    try {
                        ui.showLoading();
                        await api.deleteEvent(event.id);
                        ui.showToast('Event deleted successfully', 'Success', 'success');
                        // Refresh events
                        router.navigateTo(CONFIG.ROUTES.EVENT_MANAGEMENT);
                    } catch (error) {
                        ui.showToast(error.message || 'Failed to delete event', 'Error', 'error');
                    } finally {
                        ui.hideLoading();
                    }
                }
            });
        }
        
        return card;
    }
    
    /**
     * Create a statistics card
     * @param {string} icon - Font Awesome icon class
     * @param {number} value - Stat value
     * @param {string} label - Stat label
     * @returns {HTMLElement} Stat card element
     */
    createStatCard(icon, value, label) {
        const card = document.createElement('div');
        card.className = 'col-md-3 mb-4';
        card.innerHTML = `
            <div class="stats-card">
                <div class="d-flex align-items-center">
                    <div class="stats-card-icon">
                        <i class="fas ${icon}"></i>
                    </div>
                    <div>
                        <div class="stats-card-value">${value}</div>
                        <div class="stats-card-label">${label}</div>
                    </div>
                </div>
            </div>
        `;
        return card;
    }
    
    /**
     * Create an event form
     * @param {Object} eventData - Event data for edit mode
     * @returns {HTMLElement} Form element
     */
    createEventForm(eventData = null) {
        const form = document.createElement('form');
        form.id = 'event-form';
        form.className = 'needs-validation';
        form.setAttribute('novalidate', '');
        
        const isEditMode = !!eventData;
        
        form.innerHTML = `
            <div class="card">
                <div class="card-header">
                    <h4>${isEditMode ? 'Edit' : 'Create'} Event</h4>
                </div>
                <div class="card-body">
                    <input type="hidden" id="event-id" value="${isEditMode ? eventData.id : ''}">
                    
                    <div class="mb-3">
                        <label for="event-title" class="form-label">Event Title</label>
                        <input type="text" class="form-control" id="event-title" 
                               value="${isEditMode ? eventData.title : ''}" required>
                        <div class="invalid-feedback">Please provide an event title.</div>
                    </div>
                    
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="event-date" class="form-label">Date</label>
                            <input type="date" class="form-control" id="event-date" 
                                   value="${isEditMode ? eventData.date : ''}" required>
                            <div class="invalid-feedback">Please select a date.</div>
                        </div>
                        <div class="col-md-6">
                            <label for="event-time" class="form-label">Time</label>
                            <input type="time" class="form-control" id="event-time" 
                                   value="${isEditMode && eventData.time ? eventData.time.substring(0, 5) : ''}" required>
                            <div class="invalid-feedback">Please select a time.</div>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label for="event-type" class="form-label">Event Type</label>
                        <select class="form-select" id="event-type" required>
                            <option value="">Select Event Type</option>
                            <option value="TOURNAMENT" ${isEditMode && eventData.type === 'TOURNAMENT' ? 'selected' : ''}>Tournament</option>
                            <option value="CONFERENCE" ${isEditMode && eventData.type === 'CONFERENCE' ? 'selected' : ''}>Conference</option>
                            <option value="WORKSHOP" ${isEditMode && eventData.type === 'WORKSHOP' ? 'selected' : ''}>Workshop</option>
                            <option value="MEETUP" ${isEditMode && eventData.type === 'MEETUP' ? 'selected' : ''}>Meetup</option>
                            <option value="WEBINAR" ${isEditMode && eventData.type === 'WEBINAR' ? 'selected' : ''}>Webinar</option>
                        </select>
                        <div class="invalid-feedback">Please select an event type.</div>
                    </div>
                    
                    <div class="mb-3">
                        <label for="event-location" class="form-label">Location</label>
                        <input type="text" class="form-control" id="event-location" 
                               value="${isEditMode ? eventData.location : ''}" required>
                        <div class="invalid-feedback">Please provide a location.</div>
                    </div>
                </div>
                <div class="card-footer">
                    <button type="submit" class="btn btn-primary">
                        ${isEditMode ? 'Update' : 'Create'} Event
                    </button>
                    <button type="button" class="btn btn-secondary" id="cancel-btn">
                        Cancel
                    </button>
                </div>
            </div>
        `;
        
        // Add event listeners
        form.addEventListener('submit', async (e) => {
            e.preventDefault();
            e.stopPropagation();
            
            form.classList.add('was-validated');
            if (!form.checkValidity()) {
                return;
            }
            
            const eventData = {
                title: document.getElementById('event-title').value,
                date: document.getElementById('event-date').value,
                time: document.getElementById('event-time').value,
                type: document.getElementById('event-type').value,
                location: document.getElementById('event-location').value
            };
            
            try {
                ui.showLoading();
                const eventId = document.getElementById('event-id').value;
                
                if (eventId) {
                    await api.updateEvent(eventId, eventData);
                    ui.showToast('Event updated successfully', 'Success', 'success');
                } else {
                    await api.createEvent(eventData);
                    ui.showToast('Event created successfully', 'Success', 'success');
                }
                
                router.navigateTo(CONFIG.ROUTES.EVENT_MANAGEMENT);
            } catch (error) {
                ui.showToast(error.message || 'Failed to save event', 'Error', 'error');
            } finally {
                ui.hideLoading();
            }
        });
        
        form.querySelector('#cancel-btn').addEventListener('click', () => {
            router.navigateTo(CONFIG.ROUTES.EVENT_MANAGEMENT);
        });
        
        return form;
    }
    
    /**
     * Create a chart container
     * @param {string} id - Chart canvas ID
     * @param {string} title - Chart title
     * @returns {HTMLElement} Chart container element
     */
    createChartContainer(id, title) {
        const container = document.createElement('div');
        container.className = 'card mb-4';
        container.innerHTML = `
            <div class="card-header">
                <h5 class="mb-0">${title}</h5>
            </div>
            <div class="card-body">
                <canvas id="${id}"></canvas>
            </div>
        `;
        return container;
    }
}

// Create a global instance of the components service
const components = new Components();
