/**
 * API Service
 * Handles all API requests to the backend
 */
class ApiService {
    /**
     * Make an authenticated API request
     * @param {string} endpoint - API endpoint
     * @param {Object} options - Fetch options
     * @returns {Promise} API response
     */
    async request(endpoint, options = {}) {
        const url = `${CONFIG.API_URL}${endpoint}`;
        
        // Default options
        const defaultOptions = {
            headers: {
                'Content-Type': 'application/json'
            }
        };
        
        // Add authorization header if token exists
        if (auth.getToken()) {
            defaultOptions.headers.Authorization = `Bearer ${auth.getToken()}`;
        }
        
        // Merge options
        const fetchOptions = {
            ...defaultOptions,
            ...options,
            headers: {
                ...defaultOptions.headers,
                ...options.headers
            }
        };
        
        try {
            const response = await fetch(url, fetchOptions);
            
            // Handle unauthorized response
            if (response.status === 401) {
                auth.logout();
                throw new Error('Session expired. Please login again.');
            }
            
            // Parse response based on content type
            const contentType = response.headers.get('content-type');
            let data;
            
            if (response.status === 204) {
                data = null;
            } else if (contentType && contentType.includes('application/json')) {
                data = await response.json();
            } else {
                data = await response.text();
            }
            
            // Handle error responses
            if (!response.ok) {
                throw {
                    status: response.status,
                    message: data.message || response.statusText,
                    errors: data.errors || null,
                    data: data
                };
            }
            
            return data;
        } catch (error) {
            console.error('API request error:', error);
            throw error;
        }
    }
    
    /**
     * Get events (for organizers)
     * @returns {Promise} Events list
     */
    async getEvents() {
        return this.request('/events/');
    }
    
    /**
     * Get upcoming events (for normal users)
     * @returns {Promise} Upcoming events list
     */
    async getUpcomingEvents() {
        return this.request('/events/upcoming');
    }    /**
     * Get events report data (for organizers)
     * @returns {Promise} Events report data
     */
    async getEventsReport() {
        try {
            // First try to get the standard events report
            const response = await this.request('/events/events-report');
            
            // Ensure all required fields exist with default values
            if (response.data) {
                const defaults = {
                    totalEvents: 0,
                    upcomingEvents: 0,
                    pastEvents: 0,
                    totalRegistrations: 0,
                    recentEvents: []
                };
                
                response.data = { ...defaults, ...response.data };
                
                // If we have recentEvents but they include past events,
                // try to get upcoming events separately
                if (response.data.recentEvents && response.data.recentEvents.length > 0) {
                    try {
                        const upcomingResponse = await this.getUpcomingEvents();
                        if (upcomingResponse.data && upcomingResponse.data.length > 0) {
                            // Replace recentEvents with upcoming events
                            response.data.recentEvents = upcomingResponse.data;
                        }
                    } catch (error) {
                        console.error('Failed to get upcoming events for dashboard:', error);
                        // Keep using the original recentEvents if we can't get upcoming events
                    }
                }
            }
            
            return response;
        } catch (error) {
            console.error('Failed to get events report:', error);
            // Return a default structure if the API call fails
            return {
                data: {
                    totalEvents: 0,
                    upcomingEvents: 0, 
                    pastEvents: 0,
                    totalRegistrations: 0,
                    recentEvents: []
                }
            };
        }
    }
      /**
     * Get event analytics data (for organizers)
     * @returns {Promise} Event analytics data
     */
    async getEventAnalytics() {
        try {
            const response = await this.request('/events/events-analytics');
            return response;
        } catch (error) {
            console.error('Failed to get event analytics:', error);
            // Return empty array if the API call fails
            return { data: [] };
        }
    }
    
    /**
     * Get all event types
     * @returns {Promise} Event types list
     */
    async getEventTypes() {
        return this.request('/events/types');
    }
    
    /**
     * Create a new event
     * @param {Object} eventData - Event data
     * @returns {Promise} Created event
     */
    async createEvent(eventData) {
        return this.request('/events/', {
            method: 'POST',
            body: JSON.stringify(eventData)
        });
    }
    
    /**
     * Update an existing event
     * @param {number} eventId - Event ID
     * @param {Object} eventData - Updated event data
     * @returns {Promise} Updated event
     */
    async updateEvent(eventId, eventData) {
        return this.request(`/events/${eventId}`, {
            method: 'PUT',
            body: JSON.stringify(eventData)
        });
    }
    
    /**
     * Delete an event
     * @param {number} eventId - Event ID
     * @returns {Promise} Void
     */
    async deleteEvent(eventId) {
        return this.request(`/events/${eventId}`, {
            method: 'DELETE'
        });
    }
    
    /**
     * Register for an event
     * @param {number} eventId - Event ID
     * @returns {Promise} Registration data
     */
    async registerForEvent(eventId) {
        return this.request(`/registrations/${eventId}`, {
            method: 'POST'
        });
    }
    
    /**
     * Cancel event registration
     * @param {number} eventId - Event ID
     * @returns {Promise} Void
     */
    async cancelRegistration(eventId) {
        return this.request(`/registrations/${eventId}`, {
            method: 'DELETE'
        });
    }
    
    /**
     * Get user's registered events
     * @returns {Promise} Registered events list
     */
    async getRegisteredEvents() {
        return this.request('/registrations/my-registrations');
    }
    
    /**
     * Get current user profile
     * @returns {Promise} User profile data
     */
    async getUserProfile() {
        return this.request('/users/me');
    }
}

// Create a global instance of the API service
const api = new ApiService();
