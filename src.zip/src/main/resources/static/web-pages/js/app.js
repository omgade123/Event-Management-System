/**
 * Main Application
 * Initializes the application
 */
document.addEventListener('DOMContentLoaded', () => {
    // Initialize the application
    initApp();
});

/**
 * Initialize the application
 */
function initApp() {
    // Check current route
    const currentRoute = window.location.hash || CONFIG.ROUTES.HOME;
    const isAuthPage = currentRoute === CONFIG.ROUTES.LOGIN || currentRoute === CONFIG.ROUTES.REGISTER;
    
    // Handle UI elements visibility based on route
    document.getElementById('logout-btn').style.display = isAuthPage ? 'none' : 'block';
    
    // Check if user is already authenticated
    if (auth.isAuthenticated()) {
        // Only update UI for authenticated user if not on auth pages
        if (!isAuthPage) {
            ui.updateUserInfo();
            ui.renderSidebar();
        }
    } else {
        // Clear user name if not authenticated
        const userNameElement = document.getElementById('user-name');
        if (userNameElement) {
            userNameElement.textContent = '';
        }
    }
    
    // Setup global AJAX error handler
    setupAjaxErrorHandler();
    
    // Initialize Bootstrap tooltips and popovers
    initBootstrapComponents();
}

/**
 * Setup global AJAX error handler
 */
function setupAjaxErrorHandler() {
    // Handle fetch errors
    window.addEventListener('unhandledrejection', function(event) {
        console.error('Unhandled Promise Rejection:', event.reason);
        
        // Check if it's an API error
        if (event.reason && event.reason.status) {
            switch (event.reason.status) {
                case 401:
                    auth.logout();
                    break;
                case 403:
                    ui.showToast('You do not have permission to perform this action', 'Access Denied', 'error');
                    break;
                case 404:
                    ui.showToast('Resource not found', 'Not Found', 'error');
                    break;
                default:
                    ui.showToast(
                        event.reason.message || 'An unexpected error occurred',
                        'Error',
                        'error'
                    );
            }
        }
    });
}

/**
 * Initialize Bootstrap components
 */
function initBootstrapComponents() {
    // Initialize all tooltips
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function(tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
    
    // Initialize all popovers
    const popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'));
    popoverTriggerList.map(function(popoverTriggerEl) {
        return new bootstrap.Popover(popoverTriggerEl);
    });
}
