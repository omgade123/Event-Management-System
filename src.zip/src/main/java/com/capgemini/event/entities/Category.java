package com.capgemini.event.entities;

public enum Category {

	TOURNAMENT, CONFERENCE, WORKSHOP, MEETUP, WEBINAR
}
