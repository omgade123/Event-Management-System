package com.capgemini.event.exceptions;

public class TicketNotFoundException extends RuntimeException {

	public TicketNotFoundException(String message) {
		super(message);
	}

}
