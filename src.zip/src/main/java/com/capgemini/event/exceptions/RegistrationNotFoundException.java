package com.capgemini.event.exceptions;

public class RegistrationNotFoundException extends RuntimeException {

	public RegistrationNotFoundException(String message) {
		super(message);
	}

}
