package com.capgemini.event.entities;

public enum UserType {
    
	NORMAL, ORGANIZER, ADMIN
}