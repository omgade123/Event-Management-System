package com.capgemini.event.exceptions;

public class ResponseNotFoundException extends RuntimeException {

	public ResponseNotFoundException(String message) {
		super(message);
	}

}
